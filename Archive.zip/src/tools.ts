/**
 * Tool definitions for the AI chat agent
 * Tools can either require human confirmation or execute automatically
 */
import { formatDataStreamPart, tool } from "ai";
import { z } from "zod";

import neo4j from "neo4j-driver";
import {
  unstable_getSchedulePrompt,
  unstable_scheduleSchema,
} from "agents/schedule";
import { global_env } from "./env";
import { agentContext } from "./chatagent";
const driver = neo4j.driver(
  "neo4j://localhost:7689",

  neo4j.auth.basic("neo4j", "suntala12")
);
const session = driver.session({
  database: "neo4j",
  defaultAccessMode: neo4j.session.READ,
});

/**
 * Weather information tool that requires human confirmation
 * When invoked, this will present a confirmation dialog to the user
 * The actual implementation is in the executions object below
 */
const getWeatherInformation = tool({
  description: "show the weather in a given city to the user",
  parameters: z.object({ city: z.string() }),

  // Omitting execute function makes this tool require human confirmation
});
const getNeo4jRelaitonship = tool({
  description: "this function gets data from Neo4j",
  parameters: z.object({}),
  execute: async ({}) => {
    console.log(`Getting relationship from Neo4j `);
    const cacheId = global_env.NEO4J_CACHE.idFromName("neo4j-relationships");
    const stub = global_env.NEO4J_CACHE.get(cacheId);

    // Try to get data from cache using the stub's fetch API
    const cacheResponse = await stub.getRelationships();
    // console.log("cacheResponse", cacheResponse);
    if (cacheResponse) {
      //@ts-ignore
      const cachedData = cacheResponse;
      console.log("Using cached Neo4j relationship data");
      return JSON.parse(cachedData);
    }
    try {
      const result = await session.run(`
        MATCH ()-[r]->()
        RETURN type(r) AS RelationshipType, count(r) AS Count
        ORDER BY Count DESC
`);

      const records = result.records;
      await stub.setRelationships(JSON.stringify(records));
      console.log(records.slice(0, 5));
      return records;
    } catch (error) {
      console.error("error running query", error);
      return `Error running query: ${error}`;
      // await session.close();
    }
  },
});
const getNeo4jData = tool({
  description: "this function gets data from Neo4j",
  parameters: z.object({
    query: z.string({
      description:
        "The query to execute in Neo4j (should use LOWER() for String Comparisons)",
    }),
  }),
  execute: async ({ query }) => {
    console.log(`Getting data from Neo4j with query: ${query}`);
    try {
      const result = await session.run(query);

      const records = result.records;
      // console.log(records);
      const agent = agentContext.getStore();
      if (!agent) {
        throw new Error("No agent found");
      }
      agent.dataStream.writeData({
        neo4j_response: records,
      });

      return records;
    } catch (error) {
      console.error("error running query", error);
      return `Error running query: ${error}`;
      // await session.close();
    }
  },
});

/**
 * Local time tool that executes automatically
 * Since it includes an execute function, it will run without user confirmation
 * This is suitable for low-risk operations that don't need oversight
 */
const getLocalTime = tool({
  description: "get the local time for a specified location",
  parameters: z.object({ location: z.string() }),
  execute: async ({ location }) => {
    console.log(`Getting local time for ${location}`);
    return "10am";
  },
});

const scheduleTask = tool({
  description: "A tool to schedule a task to be executed at a later time",
  parameters: unstable_scheduleSchema,
  execute: async ({ when, description }) => {
    // we can now read the agent context from the ALS store
    const agent = agentContext.getStore();
    if (!agent) {
      throw new Error("No agent found");
    }
    function throwError(msg: string): string {
      throw new Error(msg);
    }
    if (when.type === "no-schedule") {
      return "Not a valid schedule input";
    }
    const input =
      when.type === "scheduled"
        ? when.date // scheduled
        : when.type === "delayed"
          ? when.delayInSeconds // delayed
          : when.type === "cron"
            ? when.cron // cron
            : throwError("not a valid schedule input");
    try {
      agent.schedule(input!, "executeTask", description);
    } catch (error) {
      console.error("error scheduling task", error);
      return `Error scheduling task: ${error}`;
    }
    return `Task scheduled for type "${when.type}" : ${input}`;
  },
});
/**
 * Export all available tools
 * These will be provided to the AI model to describe available capabilities
 */
export const tools = {
  getWeatherInformation,
  getLocalTime,
  scheduleTask,
  getNeo4jData,
  getNeo4jRelaitonship,
};

/**
 * Implementation of confirmation-required tools
 * This object contains the actual logic for tools that need human approval
 * Each function here corresponds to a tool above that doesn't have an execute function
 */
export const executions = {
  getWeatherInformation: async ({ city }: { city: string }) => {
    console.log(`Getting weather information for ${city}`);
    return `The weather in ${city} is freezing!`;
  },
};
